import { createContext } from "react";

const itemContext = createContext(null);

export default itemContext;
